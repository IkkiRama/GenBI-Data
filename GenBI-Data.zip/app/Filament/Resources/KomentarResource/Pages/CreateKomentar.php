<?php

namespace App\Filament\Resources\KomentarResource\Pages;

use App\Filament\Resources\KomentarResource;
use Filament\Actions;
use Filament\Resources\Pages\CreateRecord;

class CreateKomentar extends CreateRecord
{
    protected static string $resource = KomentarResource::class;
}
