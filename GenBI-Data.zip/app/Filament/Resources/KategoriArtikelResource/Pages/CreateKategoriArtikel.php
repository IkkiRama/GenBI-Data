<?php

namespace App\Filament\Resources\KategoriArtikelResource\Pages;

use App\Filament\Resources\KategoriArtikelResource;
use Filament\Actions;
use Filament\Resources\Pages\CreateRecord;

class CreateKategoriArtikel extends CreateRecord
{
    protected static string $resource = KategoriArtikelResource::class;
}
