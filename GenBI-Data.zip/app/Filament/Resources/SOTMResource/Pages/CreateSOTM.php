<?php

namespace App\Filament\Resources\SOTMResource\Pages;

use App\Filament\Resources\SOTMResource;
use Filament\Actions;
use Filament\Resources\Pages\CreateRecord;

class CreateSOTM extends CreateRecord
{
    protected static string $resource = SOTMResource::class;
}
